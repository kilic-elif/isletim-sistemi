using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Threading.Tasks;
using System.Net;

namespace ElifOS
{
    public class PremiumOS : Form
    {
        public const int WM_NCLBUTTONDOWN = 0xA1;
        public const int HT_CAPTION = 0x2;
        [DllImport("user32.dll")] public static extern int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);
        [DllImport("user32.dll")] public static extern bool ReleaseCapture();

        private Timer clockTimer;
        private Label lblTime, lblDate, lblBattery, acBat;
        private Panel startMenu, actionCenter, pnlCalendar, pnlTime, taskbar, pTime, pBat, pNet, pSnd, pnlLogin;
        
        private int winOffset = 0;
        private bool isDarkTheme = true;
        // Elif OS Base Color Theme (Deep Blue)
        private Color theme1 = Color.FromArgb(27, 58, 75);
        private Color theme2 = Color.FromArgb(13, 27, 42);

        private Dictionary<string, string> virtualDesktopFiles = new Dictionary<string, string>();
        private int internalFileY = 20;

        public PremiumOS()
        {
            this.FormBorderStyle = FormBorderStyle.None;
            this.WindowState = FormWindowState.Maximized;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Text = "ELIF OS Premium";
            this.DoubleBuffered = true;
            this.KeyPreview = true;
            this.KeyDown += (s, e) => { if (e.KeyCode == Keys.Escape || e.KeyCode == Keys.Q) this.Close(); };
            ServicePointManager.SecurityProtocol = (SecurityProtocolType)3072;

            ContextMenuStrip desktopMenu = new ContextMenuStrip();
            desktopMenu.Items.Add("\uE72A Masaüstünü Yenile").Click += (s,e)=> { this.Refresh(); };
            desktopMenu.Items.Add("-");
            desktopMenu.Items.Add("\uE790 Açık / Koyu Mod Değiştir").Click += (s,e) => ToggleTheme();
            this.ContextMenuStrip = desktopMenu;

            taskbar = new Panel { Height = 48, Dock = DockStyle.Bottom, BackColor = Color.FromArgb(240, 15, 15, 20) };
            this.Controls.Add(taskbar);

            Label startBtn = new Label { Text = "\uE782", Font = new Font("Segoe MDL2 Assets", 20), ForeColor = Color.White, AutoSize = true, Location = new Point(15, 8), Cursor = Cursors.Hand };
            startBtn.MouseEnter += (s, e) => startBtn.ForeColor = Color.DeepSkyBlue; startBtn.MouseLeave += (s, e) => startBtn.ForeColor = Color.White;
            startBtn.Click += (s, e) => ToggleStartMenu(); taskbar.Controls.Add(startBtn);

            pTime = new Panel { Size = new Size(80, 48), Cursor = Cursors.Hand, BackColor = Color.Transparent };
            pTime.MouseEnter += (s, e) => pTime.BackColor = Color.FromArgb(40, 255, 255, 255);
            pTime.MouseLeave += (s, e) => { if(!pTime.ClientRectangle.Contains(pTime.PointToClient(Control.MousePosition))) pTime.BackColor = Color.Transparent; };
            lblTime = new Label { Font = new Font("Segoe UI Semibold", 10), ForeColor = Color.White, Location = new Point(15, 6), AutoSize = true };
            lblDate = new Label { Font = new Font("Segoe UI", 8), ForeColor = Color.LightGray, Location = new Point(10, 24), AutoSize = true };
            pTime.Controls.Add(lblTime); pTime.Controls.Add(lblDate);
            pTime.MouseClick += (s,e) => ToggleCalendarTimeAction(e); lblTime.Click += (s,e) => ToggleTimePanel(); lblDate.Click += (s,e) => ToggleCalendarPanel();

            int initBat = (int)(SystemInformation.PowerStatus.BatteryLifePercent * 100);
            pBat = new Panel { Size = new Size(70, 48), Cursor = Cursors.Hand, BackColor = Color.Transparent };
            pBat.MouseEnter += (s, e) => pBat.BackColor = Color.FromArgb(40, 255, 255, 255); pBat.MouseLeave += (s, e) => { if(!pBat.ClientRectangle.Contains(pBat.PointToClient(Control.MousePosition))) pBat.BackColor = Color.Transparent; };
            lblBattery = new Label { Font = new Font("Segoe UI", 10), ForeColor = Color.White, Text = initBat + "% \uEBAE", AutoSize = true, Location = new Point(5, 12) };
            pBat.Controls.Add(lblBattery); pBat.Click += (s,e) => ToggleActionCenter(); lblBattery.Click += (s,e) => ToggleActionCenter();

            pNet = new Panel { Size = new Size(35, 48), Cursor = Cursors.Hand, BackColor = Color.Transparent };
            pNet.MouseEnter += (s, e) => pNet.BackColor = Color.FromArgb(40, 255, 255, 255); pNet.MouseLeave += (s, e) => { if(!pNet.ClientRectangle.Contains(pNet.PointToClient(Control.MousePosition))) pNet.BackColor = Color.Transparent; };
            Label lblNet = new Label { Font = new Font("Segoe MDL2 Assets", 12), ForeColor = Color.White, Text = "\uE701", AutoSize = true, Location = new Point(8, 15) };
            pNet.Controls.Add(lblNet); pNet.Click += (s,e) => ToggleActionCenter(); lblNet.Click += (s,e) => ToggleActionCenter();

            pSnd = new Panel { Size = new Size(35, 48), Cursor = Cursors.Hand, BackColor = Color.Transparent };
            pSnd.MouseEnter += (s, e) => pSnd.BackColor = Color.FromArgb(40, 255, 255, 255); pSnd.MouseLeave += (s, e) => { if(!pSnd.ClientRectangle.Contains(pSnd.PointToClient(Control.MousePosition))) pSnd.BackColor = Color.Transparent; };
            Label lblSnd = new Label { Font = new Font("Segoe MDL2 Assets", 12), ForeColor = Color.White, Text = "\uE767", AutoSize = true, Location = new Point(8, 15) };
            pSnd.Controls.Add(lblSnd); pSnd.Click += (s,e) => ToggleActionCenter(); lblSnd.Click += (s,e) => ToggleActionCenter();

            taskbar.Controls.Add(pTime); taskbar.Controls.Add(pBat); taskbar.Controls.Add(pNet); taskbar.Controls.Add(pSnd);

            taskbar.Resize += (s, e) => {
                int w = taskbar.Width; int h = this.ClientSize.Height;
                pTime.Location = new Point(w - pTime.Width - 10, 0); pBat.Location = new Point(pTime.Left - pBat.Width, 0);
                pNet.Location = new Point(pBat.Left - pNet.Width, 0); pSnd.Location = new Point(pNet.Left - pSnd.Width, 0);
                if (startMenu != null) startMenu.Location = new Point(10, h - 48 - startMenu.Height - 10);
                if (actionCenter != null) actionCenter.Location = new Point(w - actionCenter.Width - 10, h - 48 - actionCenter.Height - 10);
                if (pnlCalendar != null) pnlCalendar.Location = new Point(w - pnlCalendar.Width - 10, h - 48 - pnlCalendar.Height - 10);
                if (pnlTime != null) pnlTime.Location = new Point(w - pnlTime.Width - 10, h - 48 - pnlTime.Height - 10);
            };

            CreateDesktopIcon("\uE7E3", "CMD", 20, 20, OpenTerminalApp).ForeColor = Color.Silver;
            CreateDesktopIcon("\uE7FC", "Yılan Oyunu", 20, 120, OpenSnakeApp).ForeColor = Color.LawnGreen;
            CreateDesktopIcon("\uE928", "Mayın Tarlası", 20, 220, OpenMinesweeperApp).ForeColor = Color.Salmon;
            CreateDesktopIcon("\uE81C", "İşlemler", 20, 320, OpenTaskManagerApp).ForeColor = Color.MediumSpringGreen;
            CreateDesktopIcon("\uE1A5", "Notlar", 20, 420, () => OpenNotepadApp()).ForeColor = Color.Khaki;

            CreateDesktopIcon("\uE80F", "Sistem", 130, 20, OpenExplorerApp).ForeColor = Color.Aquamarine;
            CreateDesktopIcon("\uE774", "Web Gezgini", 130, 120, OpenBrowserApp).ForeColor = Color.DeepSkyBlue;
            CreateDesktopIcon("\uEB0F", "Hesap Mak.", 130, 220, OpenCalcApp).ForeColor = Color.Orange;
            CreateDesktopIcon("\uE706", "Açık / Koyu\nMod", 130, 320, ToggleTheme).ForeColor = Color.Yellow;

            startMenu = new Panel { Size = new Size(280, 550), BackColor = Color.FromArgb(235, 20, 25, 30), Visible = false };
            Label lblUser = new Label { Text = "\uE77B   ElifOS Pro", Font = new Font("Segoe UI Semibold", 14), ForeColor = Color.White, AutoSize = true, Location = new Point(15, 25) };
            Label div = new Label { Size = new Size(250, 1), BackColor = Color.Gray, Location = new Point(15, 65) };
            startMenu.Controls.Add(lblUser); startMenu.Controls.Add(div);
            
            startMenu.Controls.Add(CreateMenuItem("\uE80F", "Dosya Gezgini", 80, OpenExplorerApp));
            startMenu.Controls.Add(CreateMenuItem("\uE774", "Web Tarayıcı", 125, OpenBrowserApp));
            startMenu.Controls.Add(CreateMenuItem("\uE706", "Açık / Koyu Mod", 170, ToggleTheme));
            startMenu.Controls.Add(CreateMenuItem("\uE7FC", "Yılan Oyunu", 215, OpenSnakeApp));
            startMenu.Controls.Add(CreateMenuItem("\uE928", "Mayın Tarlası", 260, OpenMinesweeperApp));
            startMenu.Controls.Add(CreateMenuItem("\uE81C", "İşlem Yöneticisi", 305, OpenTaskManagerApp));
            startMenu.Controls.Add(CreateMenuItem("\uE713", "Sistem Ayarlari", 350, OpenSettingsApp));
            
            Label btnShut = new Label { Text = "\uE7E8   Sistemi Kapat", Font = new Font("Segoe UI Semibold", 11), ForeColor = Color.White, AutoSize = false, Size = new Size(280, 50), Location = new Point(0, 500), TextAlign = ContentAlignment.MiddleLeft, Padding = new Padding(20, 0, 0, 0), Cursor = Cursors.Hand };
            btnShut.MouseEnter += (s, e) => btnShut.BackColor = Color.IndianRed; btnShut.MouseLeave += (s, e) => btnShut.BackColor = Color.Transparent; btnShut.Click += (s, e) => Environment.Exit(0);
            startMenu.Controls.Add(btnShut); this.Controls.Add(startMenu);

            actionCenter = new Panel { Size = new Size(320, 320), BackColor = Color.FromArgb(235, 20, 25, 30), Visible = false };
            Label acTitle = new Label { Text = "Hizli Islem Merkezi", Font = new Font("Segoe UI Semibold", 14), ForeColor = Color.White, AutoSize = true, Location = new Point(15, 15) };
            Button btnWifi = new Button { Text = "\uE701 Wi-Fi", Font = new Font("Segoe MDL2 Assets", 12), ForeColor = Color.White, BackColor = Color.FromArgb(0, 120, 215), FlatStyle = FlatStyle.Flat, Size = new Size(130, 60), Location = new Point(20, 60) };
            btnWifi.Click += (s,e) => btnWifi.BackColor = btnWifi.BackColor == Color.Gray ? Color.FromArgb(0, 120, 215) : Color.Gray;
            Button btnBt = new Button { Text = "\uE702 Bluetooth", Font = new Font("Segoe MDL2 Assets", 12), ForeColor = Color.White, BackColor = Color.Gray, FlatStyle = FlatStyle.Flat, Size = new Size(130, 60), Location = new Point(160, 60) };
            btnBt.Click += (s,e) => btnBt.BackColor = btnBt.BackColor == Color.Gray ? Color.FromArgb(0, 120, 215) : Color.Gray;
            Label lblVol = new Label { Text = "\uE767 Ses (%50)", Font = new Font("Segoe UI", 10), ForeColor = Color.White, AutoSize = true, Location = new Point(20, 140) };
            TrackBar tbVol = new TrackBar { Minimum = 0, Maximum = 100, Value = 50, Width = 270, Location = new Point(20, 170), TickStyle = TickStyle.None };
            tbVol.Scroll += (s,e) => lblVol.Text = "\uE767 Ses (%" + tbVol.Value + ")";
            acBat = new Label { Text = "Pil Durumu: %" + initBat + " - Sistem Gucune Bagli", Font = new Font("Segoe UI", 9), ForeColor = Color.LightGray, AutoSize = true, Location = new Point(20, 240) };
            actionCenter.Controls.Add(acTitle); actionCenter.Controls.Add(btnWifi); actionCenter.Controls.Add(btnBt); actionCenter.Controls.Add(lblVol); actionCenter.Controls.Add(tbVol); actionCenter.Controls.Add(acBat);
            this.Controls.Add(actionCenter);

            pnlCalendar = new Panel { Size = new Size(250, 200), BackColor = Color.FromArgb(235, 20, 25, 30), Visible = false };
            MonthCalendar mc = new MonthCalendar { Location = new Point(10, 10) };
            pnlCalendar.Controls.Add(mc); this.Controls.Add(pnlCalendar);

            pnlTime = new Panel { Size = new Size(250, 120), BackColor = Color.FromArgb(235, 20, 25, 30), Visible = false };
            Label lTst = new Label { Text = "\uE718 Saat Ayarlari", Font = new Font("Segoe UI Semibold", 12), ForeColor = Color.White, Location = new Point(10, 10), AutoSize = true };
            Button btnCht = new Button { Text = "Sistemin Saatini Degistir", Font = new Font("Segoe UI", 9), Location = new Point(10, 50), ForeColor = Color.White, BackColor = Color.Gray, FlatStyle = FlatStyle.Flat, Size = new Size(230, 40) };
            pnlTime.Controls.Add(lTst); pnlTime.Controls.Add(btnCht); this.Controls.Add(pnlTime);

            clockTimer = new Timer { Interval = 1000 };
            clockTimer.Tick += (s, e) => { 
                lblTime.Text = DateTime.Now.ToString("HH:mm"); lblDate.Text = DateTime.Now.ToString("dd.MM.yyyy"); 
                int currentBat = (int)(SystemInformation.PowerStatus.BatteryLifePercent * 100);
                lblBattery.Text = currentBat + "% \uEBAE";
                if(acBat != null) acBat.Text = "Pil Durumu: %" + currentBat + " - Sistem";
            };
            clockTimer.Start();
            
            this.MouseClick += (s, e) => CloseAllPanels(); taskbar.MouseClick += (s, e) => CloseAllPanels();
            SetupLoginScreen();
        }

        private void CloseAllPanels() {
            if(startMenu!=null) startMenu.Visible = false; if(actionCenter!=null) actionCenter.Visible = false;
            if(pnlCalendar!=null) pnlCalendar.Visible = false; if(pnlTime!=null) pnlTime.Visible = false;
        }

        private void SetupLoginScreen()
        {
            taskbar.Visible = false;
            pnlLogin = new Panel { Dock = DockStyle.Fill, BackColor = Color.Black };

            Task.Run(async () => {
                try {
                    using(WebClient wc = new WebClient()) {
                        byte[] data = await wc.DownloadDataTaskAsync("https://picsum.photos/1920/1080?blur=4");
                        using(var ms = new System.IO.MemoryStream(data)) {
                            Image bg = Image.FromStream(ms);
                            this.Invoke(new Action(() => { pnlLogin.BackgroundImage = bg; pnlLogin.BackgroundImageLayout = ImageLayout.Stretch; }));
                        }
                    }
                } catch { this.Invoke(new Action(() => { pnlLogin.BackColor = Color.FromArgb(20, 30, 40); })); }
            });

            Panel pnlClock = new Panel { Dock = DockStyle.Fill, BackColor = Color.Transparent };
            Label lblClock = new Label { Font = new Font("Segoe UI Light", 72), ForeColor = Color.White, AutoSize = true, BackColor = Color.Transparent, Location = new Point(50, this.ClientSize.Height-350) };
            Label lblCDate = new Label { Font = new Font("Segoe UI", 24), ForeColor = Color.White, AutoSize = true, BackColor = Color.Transparent, Location = new Point(60, this.ClientSize.Height-200) };
            Label lblHint = new Label { Text = "Giriş ekranı için tıklayın veya yukarı kaydırın", Font = new Font("Segoe UI", 12), ForeColor = Color.LightGray, AutoSize = true, BackColor = Color.Transparent, Location = new Point(60, this.ClientSize.Height-120) };
            pnlClock.Controls.Add(lblClock); pnlClock.Controls.Add(lblCDate); pnlClock.Controls.Add(lblHint);
            
            Timer clockOverlay = new Timer { Interval = 1000 };
            clockOverlay.Tick += (s,e) => { lblClock.Text = DateTime.Now.ToString("HH:mm"); lblCDate.Text = DateTime.Now.ToString("dd MMMM dddd"); };
            clockOverlay.Start();

            Panel pnlGlass = new Panel { Size = new Size(420, 420), BackColor = Color.FromArgb(210, 10, 20, 35), Visible = false };
            Label lAva = new Label { Text = "\uE2AF", Font = new Font("Segoe MDL2 Assets", 76), ForeColor = Color.DeepSkyBlue, AutoSize = true, BackColor = Color.Transparent, Location = new Point(145, 30) };
            Label lName = new Label { Text = "ElifOS", Font = new Font("Segoe UI Semibold", 24), ForeColor = Color.WhiteSmoke, AutoSize = true, BackColor = Color.Transparent, Location = new Point(160, 150) };
            TextBox tPass = new TextBox { Font = new Font("Segoe UI", 16), BackColor = Color.FromArgb(30, 40, 50), ForeColor = Color.White, BorderStyle = BorderStyle.FixedSingle, UseSystemPasswordChar = true, Width = 280, TextAlign = HorizontalAlignment.Center, Location = new Point(70, 230) };
            Button btnL = new Button { Text = "Giriş Yap \uE76B", Font = new Font("Segoe UI Semibold", 14), BackColor = Color.MediumSlateBlue, ForeColor = Color.White, FlatStyle = FlatStyle.Flat, Width = 280, Height = 50, Cursor = Cursors.Hand, Location = new Point(70, 290) };
            btnL.FlatAppearance.BorderSize = 0;
            btnL.FlatAppearance.MouseOverBackColor = Color.SlateBlue;
            
            pnlGlass.Controls.Add(lAva); pnlGlass.Controls.Add(lName); pnlGlass.Controls.Add(tPass); pnlGlass.Controls.Add(btnL);
            pnlLogin.Controls.Add(pnlClock); pnlLogin.Controls.Add(pnlGlass); pnlClock.BringToFront();

            pnlLogin.Resize += (s, e) => {
                pnlGlass.Location = new Point((pnlLogin.Width - 420)/2, (pnlLogin.Height - 420)/2);
                lblClock.Location = new Point(50, pnlLogin.Height - 350);
                lblCDate.Location = new Point(60, pnlLogin.Height - 200);
                lblHint.Location = new Point(60, pnlLogin.Height - 120);
            };

            EventHandler showLogin = (ss, ee) => { pnlClock.Visible = false; pnlGlass.Visible = true; };
            pnlClock.Click += showLogin; lblClock.Click += showLogin; lblCDate.Click += showLogin; pnlLogin.Click += showLogin;

            EventHandler doLogin = (s, e) => {
                if (tPass.Text == "1234" || tPass.Text == "") { pnlLogin.Visible = false; pnlLogin.Dispose(); taskbar.Visible = true; clockOverlay.Stop(); }
                else { tPass.Text = ""; MessageBox.Show("Sifre: 1234", "Hata", MessageBoxButtons.OK, MessageBoxIcon.Error); }
            };
            btnL.Click += doLogin; tPass.KeyDown += (s, e) => { if(e.KeyCode == Keys.Enter) { e.SuppressKeyPress=true; doLogin(s, e); } };

            this.Controls.Add(pnlLogin); pnlLogin.BringToFront();
        }

        private void ToggleTheme() { 
            isDarkTheme = !isDarkTheme; 
            if(isDarkTheme) {
                theme1 = Color.FromArgb(27, 58, 75); theme2 = Color.FromArgb(13, 27, 42);
            } else {
                theme1 = Color.FromArgb(135, 206, 235); theme2 = Color.FromArgb(240, 248, 255);
            }
            this.BackgroundImage = null; this.Refresh(); 
        }
        private Label CreateMenuItem(string symbol, string text, int y, Action onClick) { Label lbl = new Label { Text = symbol + "   " + text, Font = new Font("Segoe UI", 11), ForeColor = Color.LightGray, AutoSize = false, Size = new Size(280, 40), Location = new Point(0, y), TextAlign = ContentAlignment.MiddleLeft, Padding = new Padding(20, 0, 0, 0), Cursor = Cursors.Hand }; lbl.MouseEnter += (s, e) => { lbl.BackColor = isDarkTheme ? Color.Gray : Color.DeepSkyBlue; lbl.ForeColor = Color.White; }; lbl.MouseLeave += (s, e) => { lbl.BackColor = Color.Transparent; lbl.ForeColor = Color.LightGray; }; lbl.Click += (s, e) => { ToggleStartMenu(); onClick(); }; return lbl; }
        private void ToggleStartMenu() { if(startMenu!=null) { startMenu.Visible = !startMenu.Visible; if(startMenu.Visible) startMenu.BringToFront(); } actionCenter.Visible=false; pnlCalendar.Visible=false; pnlTime.Visible=false; }
        private void ToggleActionCenter() { if(actionCenter!=null) { actionCenter.Visible = !actionCenter.Visible; if(actionCenter.Visible) actionCenter.BringToFront(); } startMenu.Visible=false; pnlCalendar.Visible=false; pnlTime.Visible=false; }
        private void ToggleCalendarPanel() { if(pnlCalendar!=null) { pnlCalendar.Visible = !pnlCalendar.Visible; if(pnlCalendar.Visible) pnlCalendar.BringToFront(); } startMenu.Visible=false; actionCenter.Visible=false; pnlTime.Visible=false;}
        private void ToggleTimePanel() { if(pnlTime!=null) { pnlTime.Visible = !pnlTime.Visible; if(pnlTime.Visible) pnlTime.BringToFront(); } startMenu.Visible=false; actionCenter.Visible=false; pnlCalendar.Visible=false;}
        private void ToggleCalendarTimeAction(MouseEventArgs e) { if (e.X > pTime.Width / 2) ToggleCalendarPanel(); else ToggleTimePanel(); }

        private Label CreateDesktopIcon(string symbol, string text, int x, int y, Action onClick) {
            Panel p = new Panel { Size = new Size(95, 95), Location = new Point(x, y), BackColor = Color.Transparent, Cursor = Cursors.Hand };
            Label icon = new Label { Text = symbol, Font = new Font("Segoe MDL2 Assets", 34), ForeColor = Color.LightGray, AutoSize = true, Location = new Point(25, 5) };
            Label lbl = new Label { Text = text, Font = new Font("Segoe UI Semibold", 9), ForeColor = Color.White, AutoSize = false, TextAlign = ContentAlignment.TopCenter, Size = new Size(95, 35), Location = new Point(0, 60) };
            p.Controls.Add(icon); p.Controls.Add(lbl);
            
            EventHandler resetHover = (s, e) => { if(!p.ClientRectangle.Contains(p.PointToClient(Control.MousePosition))) p.BackColor = Color.Transparent; };
            p.MouseEnter += (s,e)=> p.BackColor = Color.FromArgb(60, 255, 255, 255); p.MouseLeave += resetHover; icon.MouseLeave += resetHover; lbl.MouseLeave += resetHover;
            Action triggered = () => { p.BackColor = Color.Transparent; onClick(); };
            p.MouseClick += (s, e) => { if (e.Button == MouseButtons.Left) triggered(); }; icon.MouseClick += (s, e) => { if (e.Button == MouseButtons.Left) triggered(); }; lbl.MouseClick += (s, e) => { if (e.Button == MouseButtons.Left) triggered(); };
            
            ContextMenuStrip iconMenu = new ContextMenuStrip();
            iconMenu.Items.Add("Aç / Çalıştır").Click += (s,e) => triggered();
            iconMenu.Items.Add("Yeniden Adlandır").Click += (s,e) => {
                TextBox tb = new TextBox { Text = lbl.Text.Replace("\n", " "), Bounds = lbl.Bounds, Font = lbl.Font, TextAlign = HorizontalAlignment.Center };
                p.Controls.Add(tb); tb.BringToFront(); tb.Focus();
                tb.KeyDown += (ts, te) => { if(te.KeyCode == Keys.Enter) { lbl.Text = tb.Text.Replace(" ", "\n"); p.Controls.Remove(tb); } };
                tb.LostFocus += (ts, te) => { lbl.Text = tb.Text.Replace(" ", "\n"); p.Controls.Remove(tb); };
            };
            p.ContextMenuStrip = iconMenu; icon.ContextMenuStrip = iconMenu; lbl.ContextMenuStrip = iconMenu;
            this.Controls.Add(p); return icon;
        }

        private Panel CreateAppWindow(string title, int w, int h, Control content) {
            Panel win = new Panel { Size = new Size(w, h), BackColor = Color.White, BorderStyle = BorderStyle.FixedSingle };
            win.Location = new Point((this.ClientSize.Width - w)/ 2 + (winOffset * 30), (this.ClientSize.Height - h)/ 2 + (winOffset * 30));
            winOffset = (winOffset + 1) % 5;
            Panel header = new Panel { Height = 35, Dock = DockStyle.Top, BackColor = Color.FromArgb(245, 245, 245), Cursor = Cursors.Default };
            Label titleLbl = new Label { Text = title, Font = new Font("Segoe UI Semibold", 10), ForeColor = Color.Black, Location = new Point(10, 8), AutoSize = true };
            Label btnClose = new Label { Text = "\uE711", Font = new Font("Segoe MDL2 Assets", 10), Size = new Size(40, 35), Location = new Point(w - 40, 0), TextAlign = ContentAlignment.MiddleCenter, Cursor = Cursors.Hand };
            btnClose.MouseEnter += (s,e) => { btnClose.BackColor = Color.Red; btnClose.ForeColor = Color.White; }; btnClose.MouseLeave += (s,e) => { btnClose.BackColor = Color.Transparent; btnClose.ForeColor = Color.Black; }; btnClose.Click += (s,e) => win.Dispose();
            header.Controls.Add(titleLbl); header.Controls.Add(btnClose); win.Controls.Add(header);
            content.Location = new Point(0, 35); content.Size = new Size(w, h - 35); content.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            win.Controls.Add(content);
            MouseEventHandler dragHandler = (s, e) => { if (e.Button == MouseButtons.Left) { ReleaseCapture(); SendMessage(win.Handle, WM_NCLBUTTONDOWN, HT_CAPTION, 0); } win.BringToFront(); };
            header.MouseDown += dragHandler; titleLbl.MouseDown += dragHandler; win.MouseDown += (s,e) => win.BringToFront();
            this.Controls.Add(win); win.BringToFront(); CloseAllPanels(); return win;
        }

        // ================= APPLICATIONS =================
        private void OpenSnakeApp() {
            Panel p = new Panel { Size = new Size(400, 400), BackColor = Color.Black };
            typeof(Panel).InvokeMember("DoubleBuffered", System.Reflection.BindingFlags.SetProperty | System.Reflection.BindingFlags.Instance | System.Reflection.BindingFlags.NonPublic, null, p, new object[] { true });
            
            List<Point> snake = new List<Point> { new Point(10, 10) }; Point food = new Point(5, 5); Point dir = new Point(1, 0);
            Timer t = new Timer { Interval = 110 }; Random r = new Random(); int score = 0;
            p.Paint += (s, e) => {
                e.Graphics.FillRectangle(Brushes.Red, food.X * 20, food.Y * 20, 20, 20);
                for (int i = 0; i < snake.Count; i++) {
                    e.Graphics.FillRectangle(Brushes.Lime, snake[i].X * 20, snake[i].Y * 20, 20, 20);
                }
                e.Graphics.DrawString("Skor: " + score, new Font("Tahoma", 12, FontStyle.Bold), Brushes.White, 5, 5);
            };
            t.Tick += (s, e) => {
                Point head = new Point(snake[0].X + dir.X, snake[0].Y + dir.Y);
                if (head.X < 0 || head.X >= 20 || head.Y < 0 || head.Y >= 20 || snake.Contains(head)) {
                    t.Stop(); MessageBox.Show("Oyun Bitti! Puan: " + score, "Yılan Oyunu", MessageBoxButtons.OK, MessageBoxIcon.Information); 
                    snake.Clear(); snake.Add(new Point(10, 10)); dir = new Point(1, 0); score = 0; t.Start(); return;
                }
                snake.Insert(0, head); if (head == food) { score += 10; food = new Point(r.Next(0, 20), r.Next(0, 20)); } else snake.RemoveAt(snake.Count - 1);
                p.Invalidate();
            };
            p.PreviewKeyDown += (s, e) => { if (e.KeyCode == Keys.Up && dir.Y != 1) dir = new Point(0, -1); else if (e.KeyCode == Keys.Down && dir.Y != -1) dir = new Point(0, 1); else if (e.KeyCode == Keys.Left && dir.X != 1) dir = new Point(-1, 0); else if (e.KeyCode == Keys.Right && dir.X != -1) dir = new Point(1, 0); };
            Panel win = CreateAppWindow("Yilan Oyunu", 415, 455, p); win.Disposed += (s,e)=> t.Stop(); p.Focus(); p.Click += (s,e) => p.Focus(); t.Start();
        }

        private void OpenMinesweeperApp() {
            Panel p = new Panel { AutoScroll = true, BackColor = Color.FromArgb(230, 230, 230) };
            int w = 10, h = 10, mines = 15; bool[,] isMine = new bool[w, h]; Random r = new Random(); int placed = 0;
            while(placed < mines) { int x=r.Next(w), y=r.Next(h); if(!isMine[x,y]) { isMine[x,y]=true; placed++; } }
            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) {
                    Button b = new Button { Size = new Size(30, 30), Location = new Point(x * 30 + 15, y * 30 + 15), Font = new Font("Segoe UI", 10, FontStyle.Bold), BackColor = Color.LightGray, FlatStyle = FlatStyle.Flat };
                    b.FlatAppearance.BorderColor = Color.Gray; int cx = x, cy = y;
                    b.MouseDown += (s, e) => {
                        if (e.Button == MouseButtons.Right) { b.Text = b.Text == "🚩" ? "" : "🚩"; b.ForeColor=Color.Red; return; }
                        if (b.Text == "🚩") return;
                        if (isMine[cx, cy]) { b.Text = "💣"; b.BackColor = Color.Red; MessageBox.Show("BOOM! Mayına Bastın.", "Oyun Bitti", MessageBoxButtons.OK, MessageBoxIcon.Error); return; }
                        int c = 0;
                        for(int dy=-1; dy<=1; dy++) for(int dx=-1; dx<=1; dx++) { int nx=cx+dx, ny=cy+dy; if(nx>=0 && nx<w && ny>=0 && ny<h && isMine[nx,ny]) c++; }
                        b.Text = c > 0 ? c.ToString() : ""; b.BackColor = Color.White; b.Enabled = false;
                    }; p.Controls.Add(b);
                }
            }
            CreateAppWindow("Mayin Tarlasi", 350, 390, p);
        }





        private void OpenNotepadApp(string existingTitle = null, string existingContent = null) { 
            Panel p = new Panel { BackColor = Color.White };
            Panel toolBar = new Panel { Dock = DockStyle.Top, Height = 35, BackColor = Color.FromArgb(245, 245, 245) };
            TextBox txtTitle = new TextBox { Text = existingTitle ?? "Yeni_Belge", Location = new Point(10, 8), Width = 150, BorderStyle = BorderStyle.FixedSingle };
            Label lExt = new Label { Text = ".txt", Location=new Point(165, 10), AutoSize=true };
            Button btnSave = new Button { Text = "\uE74E ElifOS Sistemine Kaydet", Font = new Font("Segoe UI", 9), Height = 26, Width = 180, FlatStyle=FlatStyle.Flat, Location = new Point(200, 5), BackColor = Color.LightGreen };
            TextBox txt = new TextBox { Multiline = true, Dock = DockStyle.Fill, Font = new Font("Consolas", 12), BorderStyle = BorderStyle.None, Text = existingContent ?? "" };
            toolBar.Controls.Add(txtTitle); toolBar.Controls.Add(lExt); toolBar.Controls.Add(btnSave); p.Controls.Add(txt); p.Controls.Add(toolBar);
            
            btnSave.Click += (s, e) => { 
                string fileName = txtTitle.Text + ".txt"; virtualDesktopFiles[fileName] = txt.Text;
                bool exists = false; foreach(Control c in this.Controls) { Panel pnl = c as Panel; if (pnl != null && pnl.Size.Width == 95 && pnl.Controls.Count > 1 && pnl.Controls[1].Text == fileName) exists = true; }
                if(!exists) { CreateDesktopIcon("\uE7C3", fileName, 730, internalFileY, () => OpenNotepadApp(txtTitle.Text, virtualDesktopFiles[fileName])).ForeColor = Color.Yellow; internalFileY += 100; }
                MessageBox.Show(fileName + " masaüstüne eklendi!", "ElifOS Dosya Sistemi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            };
            CreateAppWindow(existingTitle == null ? "Not Defteri (Yeni)" : "Not Defteri - " + existingTitle, 600, 400, p); 
        }

        private void OpenExplorerApp() { Panel p = new Panel { BackColor = Color.White }; Panel toolBar = new Panel { Dock = DockStyle.Top, Height = 40, BackColor = Color.FromArgb(245, 245, 245), BorderStyle = BorderStyle.FixedSingle }; Button btnNew = new Button { Text = "\uE8F4 Yeni Klasör", Font = new Font("Segoe UI", 9), Location = new Point(10, 5), Height=30, Width=100, FlatStyle=FlatStyle.Flat }; Button btnDel = new Button { Text = "\uE74D Sil", Font = new Font("Segoe UI", 9), Location = new Point(115, 5), Height=30, Width=60, FlatStyle=FlatStyle.Flat, ForeColor=Color.Red }; TextBox txtPath = new TextBox { Text = "C:\\Kullanicilar\\ElifOS\\Masaustu", Font = new Font("Segoe UI", 10), Location = new Point(185, 8), Width=380, ReadOnly=true }; toolBar.Controls.Add(btnNew); toolBar.Controls.Add(btnDel); toolBar.Controls.Add(txtPath); TreeView tv = new TreeView { Dock = DockStyle.Left, Width = 150, BorderStyle = BorderStyle.None, Font = new Font("Segoe UI", 10) }; tv.Nodes.Add("Bu Bilgisayar").Nodes.AddRange(new[] { new TreeNode("C: Yerel Disk"), new TreeNode("D: Oyunlar") }); tv.Nodes.Add("Masaüstü"); tv.Nodes.Add("Belgeler"); tv.ExpandAll(); ListView lv = new ListView { Dock = DockStyle.Fill, BorderStyle = BorderStyle.None, View = View.Details, FullRowSelect = true, Font = new Font("Segoe UI", 10) }; lv.Columns.Add("Ad", 250); lv.Columns.Add("Değiştirme tarihi", 150); lv.Columns.Add("Tür", 100); lv.Items.Add(new ListViewItem(new[] { "Oyunlar", "01.04.2026 14:00", "Dosya Klasörü" })); lv.Items.Add(new ListViewItem(new[] { "Projelerim", "01.04.2026 09:30", "Dosya Klasörü" })); btnNew.Click += (s, e) => lv.Items.Add(new ListViewItem(new[] { "Yeni Klasör", DateTime.Now.ToString("g"), "Dosya Klasörü" })); btnDel.Click += (s, e) => { foreach(ListViewItem i in lv.SelectedItems) lv.Items.Remove(i); }; p.Controls.Add(lv); p.Controls.Add(tv); p.Controls.Add(toolBar); CreateAppWindow("Dosya Gezgini - Bu Bilgisayar", 750, 450, p); }
        private void OpenTaskManagerApp() { Panel p = new Panel { BackColor = Color.White }; Label lblCpu = new Label { Text = "CPU: %4", Font = new Font("Segoe UI", 10), Location = new Point(10, 15), AutoSize = true }; Label lblRam = new Label { Text = "RAM: 3.2 GB / 16.0 GB", Font = new Font("Segoe UI", 10), Location = new Point(120, 15), AutoSize = true }; ListBox lb = new ListBox { Location = new Point(10, 45), Size = new Size(310, 200), Font = new Font("Segoe UI", 10) }; foreach(Control c in this.Controls) { Panel pnl = c as Panel; if(pnl != null && pnl.BorderStyle == BorderStyle.FixedSingle && pnl.Size.Width > 200) { foreach(Control hc in pnl.Controls) if(hc is Panel && hc.Height == 35) foreach(Control l in hc.Controls) if(l is Label && l.Text != "\uE711") lb.Items.Add(l.Text); } } Timer tTick = new Timer { Interval = 1000 }; Random r = new Random(); tTick.Tick += (s,e) => { lblCpu.Text = "CPU: %" + r.Next(2, 22); lblRam.Text = "RAM: " + (3.0 + r.NextDouble()).ToString("0.0") + " GB"; }; tTick.Start(); Panel win = CreateAppWindow("Görev Yöneticisi", 350, 310, p); win.Disposed += (s,e) => tTick.Stop(); p.Controls.Add(lblCpu); p.Controls.Add(lblRam); p.Controls.Add(lb); }
        private void OpenSettingsApp() { Panel p = new Panel { BackColor = Color.White }; Label l = new Label { Text = "\uE713  ElifOS Ayarlari\n\nSistem Sürümü: Premium v5.0 (Aesthetic Blue)\nIslemci: Sanal C# Win32 Engine", Font = new Font("Segoe UI", 12), Padding=new Padding(20), Dock=DockStyle.Fill }; p.Controls.Add(l); CreateAppWindow("Ayarlar", 500, 350, p); }
        private void OpenBrowserApp() { Panel p = new Panel(); TextBox txtUrl = new TextBox { Dock = DockStyle.Top, Font = new Font("Segoe UI", 12), Text = "https://lite.duckduckgo.com/lite/" }; WebBrowser wb = new WebBrowser { Dock = DockStyle.Fill, ScriptErrorsSuppressed = true }; txtUrl.KeyDown += (s,e) => { if(e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; string q = txtUrl.Text; if(!q.StartsWith("http")) q = "https://lite.duckduckgo.com/lite/?q=" + Uri.EscapeDataString(q); try { wb.Navigate(q); } catch { } } }; wb.Navigated += (s,e) => { txtUrl.Text = wb.Url.ToString(); }; p.Controls.Add(wb); p.Controls.Add(txtUrl); wb.Navigate("https://lite.duckduckgo.com/lite/"); CreateAppWindow("Internet Edge", 950, 600, p); }
        private void OpenTerminalApp() { RichTextBox rtb = new RichTextBox { BackColor = Color.Black, ForeColor = Color.Lime, Font = new Font("Consolas", 12), BorderStyle=BorderStyle.None, Text = "ElifOS Command Line\nC:\\Users\\Elif> " }; rtb.KeyDown += (s,e) => { if(e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; string[] lines = rtb.Text.Split('\n'); string cmd = lines[lines.Length-1].Replace("C:\\Users\\Elif> ", "").Trim(); string res = "\n"; if(cmd == "help") res += "Komutlar: help, date, time, echo, clear"; else if(cmd == "clear") { rtb.Text = "C:\\Users\\Elif> "; rtb.SelectionStart = 16; return; } else res += "'" + cmd + "' bulunamadi."; res += "\nC:\\Users\\Elif> "; rtb.AppendText(res); rtb.SelectionStart = rtb.Text.Length; rtb.ScrollToCaret(); } }; CreateAppWindow("Terminal", 650, 400, rtb); }
        private void OpenCalcApp() { Panel p = new Panel(); TextBox txt = new TextBox { Width = 260, Height = 45, Location = new Point(20, 15), Font = new Font("Segoe UI", 24), TextAlign = HorizontalAlignment.Right, ReadOnly = true, Text = "0" }; p.Controls.Add(txt); string[] btns = { "7", "8", "9", "/", "4", "5", "6", "*", "1", "2", "3", "-", "C", "0", "=", "+" }; int x = 20, y = 75; string op = ""; double n1 = 0; bool nN = true; for(int i=0; i<16; i++) { Button b = new Button { Text = btns[i], Size = new Size(60, 50), Location = new Point(x, y), Font = new Font("Segoe UI Semibold", 16), FlatStyle = FlatStyle.Flat, BackColor = Color.White }; b.FlatAppearance.BorderColor = Color.LightGray; b.Click += (s, e) => { string t = b.Text; if(t == "C") { txt.Text = "0"; n1 = 0; op = ""; nN = true; } else if(t=="+"||t=="-"||t=="*"||t=="/") { n1 = double.Parse(txt.Text); op = t; nN = true; } else if(t=="=") { double n2 = double.Parse(txt.Text); if(op=="+") txt.Text = (n1+n2).ToString(); if(op=="-") txt.Text = (n1-n2).ToString(); if(op=="*") txt.Text = (n1*n2).ToString(); if(op=="/") txt.Text = (n1/n2).ToString(); nN = true; } else { if(nN || txt.Text=="0") txt.Text = t; else txt.Text += t; nN = false; } }; p.Controls.Add(b); x += 66; if(x > 220) { x = 20; y += 56; } } CreateAppWindow("Hesap Makinesi", 300, 350, p); }

        protected override void OnPaintBackground(PaintEventArgs e) {
            if(this.BackgroundImage != null) { base.OnPaintBackground(e); return; }
            Rectangle rc = this.ClientRectangle; if (rc.Width == 0 || rc.Height == 0) return;
            using (LinearGradientBrush b = new LinearGradientBrush(rc, theme1, theme2, LinearGradientMode.ForwardDiagonal)) e.Graphics.FillRectangle(b, rc);
        }

        [STAThread] static void Main() { Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false); Application.Run(new PremiumOS()); }
    }
}
